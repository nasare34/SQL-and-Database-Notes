USE coffee_store;
 
SELECT * FROM products;
SELECT * FROM customers;
SELECT * FROM orders;